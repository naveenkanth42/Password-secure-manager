package com.passwordmanager;

public class storeUser {
}
